import React from 'react';

const AddExpensePage = () => (
  <div>
    This is from my add expense component
  </div>
);

export default AddExpensePage;
